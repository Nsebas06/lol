// script.js
const ESP32_IP = 'http://192.168.8.198';
let motorEncendido = false;

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const loginResult = document.getElementById('login-result');

    if (username === "Admin" && password === "Admin") {
        document.querySelector('.login-container').classList.add('hidden');
        document.getElementById('motor-control-container').classList.remove('hidden');
    } else {
        loginResult.textContent = "Usuario o contraseña incorrectos";
    }
}

async function actualizarRpm() {
    if (motorEncendido) {
        try {
            const response = await fetch(`${ESP32_IP}/rpm`);
            if (response.ok) {
                const valorRpm = await response.text();
                document.getElementById('gauge-rpm-container').textContent = `RPM: ${valorRpm}`;
            }
        } catch {
            console.log("Error al obtener datos de RPM");
        }
    }
    setTimeout(actualizarRpm, 1000);
}

function cambiarEstadoMotor(accion) {
    const estadoMotor = document.getElementById('estado-motor');
    if (accion === 'encender') {
        motorEncendido = true;
        estadoMotor.textContent = "Motor encendido";
        fetch(`${ESP32_IP}/command?cmd=E`);
    } else {
        motorEncendido = false;
        estadoMotor.textContent = "Motor apagado";
        fetch(`${ESP32_IP}/command?cmd=A`);
        document.getElementById('gauge-rpm-container').textContent = 'RPM: 0';
    }
    document.getElementById('estado-movimiento-motor').textContent = '';
}

function mostrarEstado(direccion) {
    const estadoMotor = document.getElementById('estado-motor').textContent;
    const estadoMovimientoMotor = document.getElementById('estado-movimiento-motor');

    if (estadoMotor === "Motor apagado") {
        if (direccion === 'izquierda') {
            estadoMovimientoMotor.textContent = "Moviendo a la izquierda";
            fetch(`${ESP32_IP}/command?cmd=L`);
        } else if (direccion === 'derecha') {
            estadoMovimientoMotor.textContent = "Moviendo a la derecha";
            fetch(`${ESP32_IP}/command?cmd=R`);
        }
    } else {
        estadoMovimientoMotor.textContent = "No se puede cambiar de giro con el motor encendido";
    }
}

document.addEventListener('DOMContentLoaded', (event) => {
    setTimeout(actualizarRpm, 1000);
});
